import {
  ALL_PROVIDER_DETAILS,
  endpoints,
  type EndpointRecord,
  type ProviderDetail,
} from "./providers";
import { streamingProviders } from "./registry";
import type { ProviderDiagnostic } from "./types";

export interface StreamingDiagnostics {
  generatedAt: string;
  providers: ProviderDiagnostic[];
  endpointRecords: EndpointRecord[];
  unassignedEndpointRecords: EndpointRecord[];
}

function endpointHost(record: EndpointRecord): string | null {
  if (!record.baseUrl) return null;
  try {
    return new URL(record.baseUrl).hostname.toLowerCase();
  } catch {
    return null;
  }
}

function providerFailure(provider: ProviderDetail, implemented: boolean): string {
  if (implemented) return "Implementation exists; see its test request and configuration results.";
  if (provider.id === "tmdb") return "TMDB provides metadata, not media playback. No authorized stream source/extraction provider is registered.";
  if (provider.id === "trakt") return "No current documented playback contract or authorized media source is configured; the observed paths describe API/OAuth, not stream delivery.";
  if (provider.id === "app-backend") return "HTTP method, request parameters, authentication, response schema, and authorization for the observed stream path are missing.";
  if (provider.kind === "scraper-domain") return "Documented request/response contract, movie and episode extraction methods, and authorization are missing. Domain or path evidence alone is not implemented.";
  if (provider.kind === "media-host") return "Authorized content mapping, supported media endpoint contract, and any required provider resolver/authentication are missing.";
  return "No documented and authorized movie/episode media extraction contract is configured.";
}

async function probeTmdbMetadata(fetcher: typeof fetch, configuredKey?: string): Promise<{ succeeded: boolean | null; reason: string }> {
  const key = (configuredKey ?? process.env.TMDB_API_KEY)?.trim();
  if (!key || key === "your_tmdb_api_key") {
    return { succeeded: null, reason: "Not tested: TMDB_API_KEY is not configured. This would test metadata only, not playback." };
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const tmdbBase = (process.env.TMDB_BASE_URL?.trim() || "https://api.themoviedb.org/3").replace(/\/+$/, "");
    const url = new URL(`${tmdbBase}/movie/550`);
    url.searchParams.set("api_key", key);
    const response = await fetcher(url, { method: "GET", redirect: "error", signal: controller.signal, cache: "no-store" });
    if (!response.ok) return { succeeded: false, reason: `TMDB metadata probe returned HTTP ${response.status}; it does not test playback.` };
    const data = await response.json() as { id?: number };
    return data.id === 550
      ? { succeeded: true, reason: "TMDB metadata probe succeeded; TMDB does not supply the playable movie stream." }
      : { succeeded: false, reason: "TMDB metadata probe returned an unexpected record; it does not test playback." };
  } catch (error) {
    return { succeeded: false, reason: error instanceof Error && error.name === "AbortError" ? "TMDB metadata probe timed out." : "TMDB metadata probe failed; it does not test playback." };
  } finally {
    clearTimeout(timeout);
  }
}

export async function getStreamingDiagnostics(options: {
  probe?: boolean;
  fetcher?: typeof fetch;
  tmdbApiKey?: string;
} = {}): Promise<StreamingDiagnostics> {
  const fetcher = options.fetcher || fetch;
  const providers = await Promise.all(ALL_PROVIDER_DETAILS.map(async (provider): Promise<ProviderDiagnostic> => {
    const implementation = streamingProviders.find((candidate) => candidate.id === provider.id);
    const implemented = Boolean(implementation);
    const providerHosts = new Set(provider.domains.map((domain) => domain.toLowerCase()));
    if (provider.baseUrl) {
      try { providerHosts.add(new URL(provider.baseUrl).hostname.toLowerCase()); } catch { /* Keep recorded domains only. */ }
    }
    const relatedEndpoints = endpoints.filter((record) => {
      const host = endpointHost(record);
      return Boolean(host && providerHosts.has(host));
    });
    const configured = Boolean(implementation?.enabled && (implementation.isConfigured?.() ?? true));
    const isTmdb = provider.id === "tmdb";
    const probe = isTmdb && options.probe ? await probeTmdbMetadata(fetcher, options.tmdbApiKey) : {
      succeeded: null,
      reason: isTmdb ? "Not tested. Request diagnostics with ?probe=true to check TMDB metadata access." : providerFailure(provider, implemented),
    };

    return {
      id: provider.id,
      name: provider.name,
      kind: provider.kind,
      providerEvidence: provider.evidence,
      implementationExists: implemented,
      configurationComplete: configured,
      documentedApi: isTmdb,
      searchMethodConfirmed: isTmdb,
      movieStreamExtractionConfirmed: false,
      tvEpisodeExtractionConfirmed: false,
      resolverConfirmed: Boolean(implementation?.resolve),
      testRequestSucceeded: probe.succeeded,
      playableMediaVerified: false,
      failureReason: isTmdb ? probe.reason : providerFailure(provider, implemented),
      endpoints: relatedEndpoints.map((record) => ({
        name: record.name,
        baseUrl: record.baseUrl,
        path: record.path,
        method: record.method,
        evidence: record.evidence,
      })),
    };
  }));

  const assigned = new Set(providers.flatMap((provider) => provider.endpoints.map((endpoint) => endpoint.name)));
  return {
    generatedAt: new Date().toISOString(),
    providers,
    endpointRecords: endpoints,
    unassignedEndpointRecords: endpoints.filter((record) => !record.baseUrl || !assigned.has(record.name)),
  };
}
