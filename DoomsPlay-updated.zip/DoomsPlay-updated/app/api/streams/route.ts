import { NextRequest, NextResponse } from "next/server";
import { discoverStreams } from "@/lib/streaming/manager";
import type { MediaKind } from "@/lib/streaming/types";
import { streamingProviders } from "@/lib/streaming/registry";
import { getStreamingDiagnostics } from "@/lib/streaming/diagnostics";

export const dynamic = "force-dynamic";

export async function GET() {
  const diagnostics = await getStreamingDiagnostics();
  return NextResponse.json({
    providers: diagnostics.providers,
    endpointRecords: diagnostics.endpointRecords,
    unassignedEndpointRecords: diagnostics.unassignedEndpointRecords,
    activePlaybackProviders: streamingProviders.filter((provider) => provider.enabled).map(({ id, name, supports }) => ({ id, name, supports })),
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const tmdbId = String(body?.tmdbId ?? "").trim();
    const mediaType = body?.mediaType as MediaKind;
    const season = Number(body?.season ?? 1);
    const episode = Number(body?.episode ?? 1);

    if (!/^\d{1,12}$/.test(tmdbId)) {
      return NextResponse.json({ error: "A valid TMDB ID is required" }, { status: 400 });
    }
    if (mediaType !== "movie" && mediaType !== "tv") {
      return NextResponse.json({ error: "mediaType must be movie or tv" }, { status: 400 });
    }
    if (mediaType === "tv" && (!Number.isInteger(season) || !Number.isInteger(episode) || season < 1 || episode < 1 || season > 100 || episode > 500)) {
      return NextResponse.json({ error: "Invalid season or episode" }, { status: 400 });
    }

    const result = await discoverStreams({
      tmdbId,
      mediaType,
      title: typeof body?.title === "string" ? body.title.slice(0, 180) : undefined,
      year: Number.isInteger(body?.year) ? body.year : undefined,
      season,
      episode
    });
    const diagnostics = await getStreamingDiagnostics();

    return NextResponse.json({
      success: true,
      configuredProviders: result.providers.length,
      sources: result.sources,
      providers: result.providers,
      providerStatus: diagnostics.providers.map((provider) => ({
        id: provider.id,
        name: provider.name,
        playbackAvailable: provider.playableMediaVerified,
        reason: provider.failureReason,
      })),
      message: result.sources.length === 0 && result.providers.length === 0
        ? "No supplied provider has a documented, authorized playback implementation configured. See provider status for the specific missing information."
        : undefined
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("[API /streams]", error);
    return NextResponse.json({ error: "Unable to discover streaming sources" }, { status: 500 });
  }
}
