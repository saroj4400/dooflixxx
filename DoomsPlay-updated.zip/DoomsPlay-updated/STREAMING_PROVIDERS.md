# DoomsPlay streaming status

## Current playback flow

The existing watch page sends the selected TMDB ID, media kind, and (for TV) season and episode to `POST /api/streams`. The route calls `lib/streaming/manager.ts`, which runs only enabled modules registered in `lib/streaming/registry.ts`. The manager validates normalized media sources and the `ServerSelector` lets the viewer choose one manually. The selected HLS, DASH, MP4, or WebM source is then bound to the player in `components/VideoPlayer.tsx`. An iframe is accepted only when a registered provider explicitly marks it as its own authorized player. There is no automatic source fallback.

The evidence inventory in `lib/streaming/providers/index.ts` is kept separate from the executable registry. That file remains unchanged: its original provider IDs, metadata, endpoint records, evidence labels, types, and exports are preserved. A listed domain or path is not an active provider.

At present, `lib/streaming/registry.ts` contains no active integrations. Consequently the API correctly returns no playback sources. The modular architecture is testable with isolated test fixtures, but no supplied provider currently has enough documented authorization and API information to register as a real movie/episode source.

## Provider-by-provider assessment

| Existing ID | Name | Existing evidence | Playback status and missing information |
| --- | --- | --- | --- |
| `app-backend` | PlayLT / App Backend | Confirmed URL string | A decompiled call site shows a POST to the recorded stream path with an `id` JSON field. It is not live-tested or established as authorized for this website. Authentication policy, supported IDs, response contract, and permission to use the service are missing. Kept disabled. |
| `tmdb` | The Movie Database (TMDB) | Confirmed URL string | Documented metadata/search and TV-season APIs; not a media delivery source. A TMDB key is optional for metadata only. No movie or episode playback extraction. |
| `trakt` | Trakt | Confirmed URL string | API/OAuth references only. No configured client, current playback contract, or media delivery interface. |
| `gofile-api` | Gofile API | Confirmed URL strings | Account/content API strings do not identify authorized movie or episode IDs. No catalog mapping or permission for a content source is configured. |
| `drivehub` | DriveHub / ExtraDrive | Domain only | Scraper/domain references only; no documented authorized request/response contract or content mapping. |
| `hdhub` | HDHub | Domain only | Scraper/domain references only; no documented authorized request/response contract or content mapping. |
| `hdm2` | HDm2 / HDFLIX | Path pattern | Player/AJAX path references; no supported authorized integration contract. |
| `mkv` | MKV | Domain only | Scraper and downstream host references; no documented authorized movie/episode API. |
| `superstream` | SuperStream | Path pattern | `/play/` pattern and configuration-key names only; the concrete origin and authorized API contract are unavailable. |
| `watchkar` | Watchkar | Domain only | Host references and an HLS-related code reference; no general documented API, permission, or catalog-to-content mapping. |
| `gdtot` | GDTOT / GDTOT-V2 | Path pattern | File/download path patterns only; no authorized source mapping or supported resolver contract. |
| `hdmovie2` | HDMovie2 | Domain only | Domain and UI/scraper class references only. No documented authorization or playback API. |
| `hubcloud` | HubCloud | Domain only | Downstream host reference; not a catalog or authorized media-source API. |
| `pixeldrain` | PixelDrain | Path pattern | File API/path references; no authorized content IDs or catalog mapping supplied. |
| `gofile` | Gofile | Path pattern | Host URL pattern only; no authorized content mapping supplied. |
| `vidsrc` | VidSrc | Path pattern | Embed/AJAX path references; no authorized or stable playback contract supplied. |
| `other-hosts` | Other embedded host domains | Domain only | Hostname references only; no documented endpoint contract or authorized content mapping. |

The full endpoint records, domains, evidence labels, observed parameter/header names, and notes remain in `lib/streaming/providers/index.ts` and are returned by `GET /api/streams` and `GET /api/streaming/diagnostics`. Every endpoint record there retains its original evidence and HTTP-method value. The diagnostics response does not equate an observed endpoint with a working provider.

## APK inspection findings

See [APK_REVERSE_ENGINEERING_REPORT.md](./APK_REVERSE_ENGINEERING_REPORT.md) for verified package structure and the limits of what the decompilation established. It records architectural facts only; no APK implementation code is copied into DoomsPlay.

## Diagnostics and API behavior

- `GET /api/streams` returns the complete provider evidence inventory, active playback provider summary, and endpoint records.
- `POST /api/streams` accepts a numeric TMDB ID and `mediaType: "movie" | "tv"`. TV requests also carry positive integer `season` and `episode` values. Valid requests return an empty `sources` array when no authorized module is registered; invalid IDs/types/episodes return HTTP 400.
- `GET /api/streaming/diagnostics` gives a per-provider report with evidence class, implementation/configuration status, search/extraction/resolver flags, test-request status, playable-media status, associated endpoint records, and a failure reason. `?probe=true` can probe TMDB metadata if `TMDB_API_KEY` is configured; this is explicitly not a playback test.
- Redirect and stream validation require HTTPS, a module-declared hostname allowlist, bounded redirects, and a media MIME type. HTML interstitials and unallowlisted/private URLs are rejected before player selection.
- Playback support is implemented in the player for HLS (hls.js or native HLS), DASH (dash.js), MP4/WebM (browser video), subtitles, manual source switching, and marked provider-owned iframes. These are player capabilities, not proof any supplied provider returns playable media.

## Environment and deployment

`.env.example` contains only `TMDB_API_KEY=`. It is optional for streaming discovery and required only if the existing catalog integration needs live TMDB metadata. Supabase is not required by the streaming route or for building the site; its client throws a clear error only when an account feature explicitly calls it without configuration.

Install and run locally:

```powershell
npm install
npm run dev
```

Verification commands:

```powershell
npx tsc --noEmit
npm run lint
npm test
npm run build
npx opennextjs-cloudflare build
```

For Cloudflare, set `TMDB_API_KEY` as a Worker secret only if live metadata is needed. Then run `npm run preview:cloudflare` to preview and `npm run deploy:cloudflare` to deploy. Never include `.env.local` in source control or deployment archives.

## Verification limits

The streaming test suite covers API validation/discovery, provider-manager movie and TV argument flow, MIME/redirect validation, and player source binding. It passed in this workspace. The production Next build and OpenNext Cloudflare bundle also completed. Build-time catalog fetches were blocked by the local network sandbox and logged `EACCES`, though static generation completed.

No real provider returned an authorized movie or episode source. This environment had no configured authorized media source, so an actual browser decode/playback test could not be performed. The project does not substitute a sample video or claim playback success.
