# CineMate — Modern Cinematic Streaming & Discovery Platform

CineMate is a production-ready, mobile-first movie and TV discovery web application built with Next.js (App Router), React, TypeScript, and Tailwind CSS. It features a modern dark cinematic user interface inspired by premium streaming platforms, with complete client-side watchlist persistence, responsive carousels, instant live search, and deeply decoupled services for TMDB metadata and multiple video player providers.

> **Key Architectural Principle:**  
> **"TMDB API and player providers are intentionally separated from the UI so they can be configured after the repository is completed."**  
> You can deploy this repository immediately with verified demo data and streams, and later connect your live TMDB API key and authorized player embed gateways without rewriting any frontend components.

---

## Table of Contents

1. [Features](#features)
2. [Project Structure](#project-structure)
3. [Quick Start](#quick-start)
4. [Environment Variables & TMDB Setup](#environment-variables--tmdb-setup)
5. [Multiple Player Provider Configuration](#multiple-player-provider-configuration)
6. [Data Architecture](#data-architecture)
7. [Production Build](#production-build)
8. [License & Disclaimers](#license--disclaimers)

---

## Features

- **Mobile-First Experience**: Ergonomically crafted for smartphones and tablets with a sleek floating bottom navigation bar, frosted mobile drawer menu, and touch-momentum carousels.
- **Hero Carousel**: Auto-advancing multi-slide showcase featuring rich metadata badges (`4K UHD`, `HDR`, `TV-MA`, `PG-13`), star ratings, genres, and instant "+ My List" toggle.
- **Top 10 Global Rankings**: Stylized outlined rank typography (`1` to `10`) overlapping high-res posters with hover playback triggers.
- **Live Search with Quick Chips**: Instant search filtering across titles, genres, actors, and directors, accompanied by media type tabs and trending search suggestions.
- **Persistent "My List" Watchlist**: Hydration-safe `localStorage` synchronization with reactive counter badges and individual deletion controls.
- **Movie & TV Details**: Full-bleed backdrop presentations, audio/video specs (Dolby Atmos, 5.1 Surround, CC), and "More Like This" recommendation carousels.
- **Episodic Television Hub**: Dedicated season switcher and episode browser with preview thumbnails, runtime, and direct episode playback triggers.
- **Multi-Server Watch Player**: Dynamic switcher supporting multiple authorized player gateways (Player 1, Player 2, Player 3, Player 4) with Previous/Next episode navigation and loading/unavailable fallbacks.
- **Resilient Image Handling**: Custom `ImageWithFallback` component that guarantees no broken image icons ever appear.

---

## Project Structure

```text
cinemate/
├── app/
│   ├── layout.tsx             # Root layout with MyListProvider, Header, Footer, and MobileNav
│   ├── globals.css            # Dark cinematic theme, animations, and no-scrollbar utilities
│   ├── loading.tsx            # Global shimmer skeleton loading state
│   ├── error.tsx              # Error boundary with recovery action
│   ├── not-found.tsx          # Custom 404 error page
│   ├── page.tsx               # Home feed (Hero, Trending, Top 10s, Genre rows)
│   ├── movies/                # Movies catalog with genre filtering & sorting
│   ├── tv/                    # TV series catalog with genre filtering & sorting
│   ├── new-popular/           # New releases & global Top 10 rankings
│   ├── search/                # Live multi-filter search experience
│   ├── my-list/               # Client-side persistent watchlist
│   ├── movie/[id]/            # Movie details page with recommendations
│   ├── tv/[id]/               # TV show details page with seasons & episodes
│   └── watch/[id]/            # Multi-provider video player & episode switcher
├── components/
│   ├── Header.tsx             # Sticky glass header & mobile hamburger drawer
│   ├── MobileNav.tsx          # Floating mobile bottom dock with dynamic badge
│   ├── Hero.tsx               # Auto-play hero carousel with interactive controls
│   ├── MediaCard.tsx          # Movie/TV card with hover overlay & quick actions
│   ├── Section.tsx            # Horizontal smooth carousel with desktop chevrons
│   ├── Top10.tsx              # Stylized 3D numeric rank carousel
│   ├── SearchClient.tsx       # Live search engine with filter chips
│   ├── Player.tsx             # Responsive iframe & HTML5 video container
│   ├── SeasonSelector.tsx     # Standalone season tab selector
│   ├── EpisodeSelector.tsx    # Standalone episode grid selector
│   ├── WatchClient.tsx        # Multi-provider switcher & TV playlist controls
│   ├── ImageWithFallback.tsx  # Image component with branded error placeholder
│   └── Footer.tsx             # Cinematic footer with navigation & disclaimer
├── context/
│   └── MyListContext.tsx      # React context with localStorage persistence
├── data/
│   ├── movies.ts              # Local curated movies dataset
│   ├── tv.ts                  # Local curated TV series & episodes dataset
│   ├── genres.ts              # Standard TMDB-aligned genre mappings
│   └── media.ts               # Aggregator maintaining backward compatibility
├── lib/
│   ├── api.ts                 # Unified application data gateway
│   ├── tmdb.ts                # Isolated server-side TMDB API integration
│   └── player.ts              # Multi-provider player URL generator service
├── types/
│   ├── movie.ts               # Movie data definitions
│   ├── tv.ts                  # TVShow, Season, Episode data definitions
│   ├── player.ts              # PlayerProvider, MoviePlayer, TVPlayer definitions
│   └── media.ts               # Unified Media types
├── .env.example               # Template for environment variables
└── next.config.ts             # Remote image patterns & build configuration
```

---

## Quick Start

### 1. Installation

```bash
npm install
```

### 2. Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to explore CineMate.

---

## Environment Variables & TMDB Setup

The TMDB integration service is isolated in [`lib/tmdb.ts`](lib/tmdb.ts). All TMDB API requests run exclusively on the server side and never expose API keys to client browsers.

### Configuration Steps:

1. Create a `.env.local` file in the project root (or copy `.env.example`):
   ```bash
   cp .env.example .env.local
   ```
2. Add your legitimate TMDB API key:
   ```env
   TMDB_API_KEY=your_actual_tmdb_api_key_here
   ```
3. Restart your dev server (`npm run dev`).

**Automatic Fallback Behavior:**  
If `TMDB_API_KEY` is not provided or if offline, the application seamlessly and gracefully falls back to the curated high-resolution mock data in `data/`, ensuring the website remains 100% functional without any crashes or missing assets.

---

## Multiple Player Provider Configuration

Player provider management is centralized in [`lib/player.ts`](lib/player.ts). React components do not hard-code player URLs; they request URLs dynamically from `lib/player.ts`.

### Pre-Configured Providers:

- **Player 1**: Standard HTML5 Demo Video (`BigBuckBunny.mp4` public domain stream)
- **Player 2**: Authorized Server A (`https://authorized-provider-alpha.example/movie/{id}`)
- **Player 3**: Authorized Server B (`https://authorized-provider-beta.example/embed/movie/{id}`)
- **Player 4**: Backup Server (`https://authorized-provider-gamma.example/watch/{id}`)

### Adding or Updating Providers:

In [`lib/player.ts`](lib/player.ts), update the `defaultPlayerProviders` array:

```typescript
{
  id: "provider-custom",
  name: "Player Custom",
  movieUrlTemplate: "https://your-authorized-cdn.com/movie/{id}",
  tvUrlTemplate: "https://your-authorized-cdn.com/tv/{id}/{season}/{episode}",
  enabled: true,
  priority: 1,
  isDirectVideo: false // set to true if template returns direct mp4/m3u8
}
```

The tokens `{id}`, `{season}`, and `{episode}` are automatically replaced by the player service with URI-encoded values.

---

## Production Build

To test production bundling, type-checking, and static page optimization:

```bash
npm run build
npm start
```

---

## Disclaimers & Security

- **Safe Video Sources**: CineMate only utilizes authorized and public domain video sources for demonstration purposes. Do not scrape or configure unauthorized streaming sources.
- **Environment Security**: `.env`, `.env.local`, and all variations are explicitly ignored in `.gitignore`. Never commit API keys or production secrets to Git.
- **Future Expansion**: The repository does not include an admin panel, admin authentication, or database at this stage, keeping the architecture lightweight, modular, and ready for future administrative extensions.
