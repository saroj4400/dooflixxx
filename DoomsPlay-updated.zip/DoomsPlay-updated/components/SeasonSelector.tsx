"use client";

import { Layers } from "lucide-react";

interface SeasonSelectorProps {
  seasons: number[];
  activeSeason: number;
  onSeasonChange: (season: number) => void;
  totalEpisodes?: number;
}

export function SeasonSelector({
  seasons,
  activeSeason,
  onSeasonChange,
  totalEpisodes
}: SeasonSelectorProps) {
  if (!seasons || seasons.length <= 1) {
    return null;
  }

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
      <div className="flex items-center gap-2 text-sm font-bold text-white/70">
        <Layers size={16} className="text-red-500" />
        <span>Seasons</span>
        {totalEpisodes && (
          <span className="text-xs text-white/40">({totalEpisodes} Episodes)</span>
        )}
      </div>

      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
        {seasons.map((s) => {
          const isActive = s === activeSeason;
          return (
            <button
              key={s}
              onClick={() => onSeasonChange(s)}
              className={`rounded-xl px-4 py-2 text-xs font-bold transition-all active:scale-95 ${
                isActive
                  ? "bg-red-600 text-white font-bold shadow-md shadow-red-600/30"
                  : "border border-white/10 bg-white/5 text-white/60 hover:border-white/20 hover:text-white"
              }`}
            >
              Season {s}
            </button>
          );
        })}
      </div>
    </div>
  );
}
