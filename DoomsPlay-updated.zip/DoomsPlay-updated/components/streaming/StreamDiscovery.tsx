"use client";

import { useCallback, useEffect, useState } from "react";
import { AlertCircle, Loader2, Search, Server } from "lucide-react";
import type { ProviderIntegrationStatus, StreamSource } from "@/lib/streaming/types";
import { ServerSelector } from "@/components/ServerSelector";
import { StreamingVideoPlayer } from "@/components/VideoPlayer";

interface Props {
  tmdbId: string;
  mediaType: "movie" | "tv";
  title: string;
  season?: number;
  episode?: number;
  year?: number;
  poster?: string;
}

interface DiscoveryResponse {
  success: boolean;
  configuredProviders: number;
  sources: StreamSource[];
  providers: Array<{ providerId: string; providerName: string; status: string; sourceCount: number; message?: string }>;
  providerStatus: ProviderIntegrationStatus[];
  message?: string;
  error?: string;
}

export function StreamDiscovery(props: Props) {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<DiscoveryResponse | null>(null);
  const [selected, setSelected] = useState<StreamSource | null>(null);
  const [error, setError] = useState("");

  const discover = useCallback(async () => {
    setLoading(true);
    setError("");
    setSelected(null);
    try {
      const response = await fetch("/api/streams", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tmdbId: props.tmdbId,
          mediaType: props.mediaType,
          title: props.title,
          year: props.year,
          season: props.season,
          episode: props.episode,
        }),
      });
      const result = await response.json() as DiscoveryResponse;
      if (!response.ok) throw new Error(result.error || "Source discovery failed");
      setData(result);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Source discovery failed");
    } finally {
      setLoading(false);
    }
  }, [props.tmdbId, props.mediaType, props.title, props.year, props.season, props.episode]);

  useEffect(() => {
    setData(null);
    setSelected(null);
    setError("");
  }, [props.tmdbId, props.mediaType, props.season, props.episode]);

  const providerStatus = data?.providerStatus || [];

  return (
    <section className="w-full space-y-3 rounded-2xl border border-white/10 bg-[#09090e] p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Server size={17} className="text-cinema" />
          <div>
            <h3 className="text-sm font-bold text-white">Authorized provider sources</h3>
            <p className="text-[11px] text-white/45">{props.mediaType === "tv" ? `TMDB ${props.tmdbId} · S${props.season} E${props.episode}` : `TMDB ${props.tmdbId}`}</p>
          </div>
        </div>
        <button onClick={discover} disabled={loading} className="inline-flex items-center gap-2 rounded-xl bg-cinema px-4 py-2 text-xs font-bold text-black disabled:opacity-60">
          {loading ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />}
          {loading ? "Searching providers…" : "Find sources"}
        </button>
      </div>

      {error && <p role="alert" className="flex items-center gap-2 text-xs text-red-300"><AlertCircle size={14} />{error}</p>}
      {data?.message && <p className="text-xs leading-5 text-amber-200/75">{data.message}</p>}
      {data?.providers.map((provider) => (
        <p key={provider.providerId} className="flex items-center gap-2 text-xs text-white/60">
          <AlertCircle size={13} className="text-amber-400" />
          {provider.providerName}: {provider.sourceCount} source(s){provider.message ? ` · ${provider.message}` : ""}
        </p>
      ))}

      <ServerSelector
        sources={data?.sources || []}
        selectedSourceId={selected ? `${selected.providerId}:${selected.id}` : null}
        providerStatus={providerStatus}
        onSelectSource={setSelected}
      />

      {selected && <div className="space-y-2">
        <p className="text-xs font-semibold text-white">Selected source: {selected.providerName} · {selected.title}</p>
        <StreamingVideoPlayer source={selected} title={props.title} poster={props.poster} />
      </div>}
    </section>
  );
}
