import { streamingProviders } from "./registry";
import { resolveProviderSource } from "./resolver";
import type { ProviderRunResult, StreamRequest, StreamSource, StreamingProvider } from "./types";

const PROVIDER_TIMEOUT_MS = 12_000;

export async function discoverStreams(
  request: StreamRequest,
  providers: StreamingProvider[] = streamingProviders,
  fetcher: typeof fetch = fetch,
): Promise<{
  sources: StreamSource[];
  providers: ProviderRunResult[];
}> {
  const eligible = providers.filter((provider) =>
    provider.enabled && provider.supports[request.mediaType]
  );

  const settled = await Promise.all(eligible.map(async (provider) => {
    let timeout: ReturnType<typeof setTimeout> | undefined;
    try {
      const timeoutPromise = new Promise<never>((_, reject) => {
        timeout = setTimeout(() => reject(new Error("Provider timed out")), PROVIDER_TIMEOUT_MS);
      });
      const providerWork = (async () => {
        const rawSources = await provider.getSources(request);
        return Promise.all(rawSources.map((source) => resolveProviderSource(source, provider, request, fetcher)));
      })();
      const resolvedSources = await Promise.race([providerWork, timeoutPromise]);
      const sources = resolvedSources.filter((source): source is StreamSource => Boolean(source));
      return {
        sources,
        result: {
          providerId: provider.id,
          providerName: provider.name,
          status: sources.length ? "ok" as const : "empty" as const,
          sourceCount: sources.length,
          message: sources.length ? undefined : "No verified, playable media source returned"
        }
      };
    } catch (error) {
      return {
        sources: [],
        result: {
          providerId: provider.id,
          providerName: provider.name,
          status: "error" as const,
          sourceCount: 0,
          message: error instanceof Error ? error.message : "Provider request failed"
        }
      };
    } finally {
      if (timeout) clearTimeout(timeout);
    }
  }));

  const sources = settled.flatMap((item) => item.sources);
  const unique = [...new Map(sources.map((source) => [source.url, source])).values()];
  return { sources: unique, providers: settled.map((item) => item.result) };
}
