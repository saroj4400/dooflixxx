import type { StreamingProvider } from "./types";

/** Runtime implementations are separate from the APK evidence inventory. */
export const streamingProviders: StreamingProvider[] = [];
