/** Server-side contracts for DoomsPlay's modular streaming provider system. */
export type MediaKind = "movie" | "tv";
export type StreamKind = "hls" | "dash" | "mp4" | "webm" | "iframe";

export interface StreamRequest {
  tmdbId: string;
  mediaType: MediaKind;
  title?: string;
  year?: number;
  season?: number;
  episode?: number;
}

export interface StreamSource {
  id: string;
  providerId: string;
  providerName: string;
  title: string;
  url: string;
  kind: StreamKind;
  quality?: string;
  language?: string;
  /** True when the provider requires its own authorized embed player. */
  requiresProviderPlayer?: boolean;
  subtitles?: Array<{
    url: string;
    language: string;
    label: string;
    isDefault?: boolean;
  }>;
}

export interface ProviderIntegrationStatus {
  id: string;
  name: string;
  playbackAvailable: boolean;
  reason?: string;
}

export interface StreamingProvider {
  id: string;
  name: string;
  enabled: boolean;
  supports: { movie: boolean; tv: boolean };
  /** Explicit host allowlist copied from this integration's own documentation. */
  allowedHosts?: string[];
  /** Optional check for the configuration needed by this module. */
  isConfigured?(): boolean;
  /** Return sources for a movie or a specific TV episode. Implementations run server-side. */
  getSources(request: StreamRequest): Promise<StreamSource[]>;
  /** Optional provider-owned URL resolution. Must not bypass DRM, login walls or access controls. */
  resolve?(source: StreamSource, request: StreamRequest): Promise<StreamSource | null>;
}

export interface ProviderRunResult {
  providerId: string;
  providerName: string;
  status: "ok" | "empty" | "error";
  sourceCount: number;
  message?: string;
}

export interface ProviderDiagnostic {
  id: string;
  name: string;
  kind: string;
  providerEvidence: string;
  implementationExists: boolean;
  configurationComplete: boolean;
  documentedApi: boolean;
  searchMethodConfirmed: boolean;
  movieStreamExtractionConfirmed: boolean;
  tvEpisodeExtractionConfirmed: boolean;
  resolverConfirmed: boolean;
  testRequestSucceeded: boolean | null;
  playableMediaVerified: boolean;
  failureReason: string;
  endpoints: Array<{
    name: string;
    baseUrl?: string;
    path: string;
    method: string;
    evidence: string;
  }>;
}
